Jere Sotaniemi
jsotanie21@student.oulu.fi
Student number: 67931749240

Additional features I have:
    - Feature 5: Attach weather when sightseeing information is requested
    - Feature 6: User can create sightseeing paths with custon tour message